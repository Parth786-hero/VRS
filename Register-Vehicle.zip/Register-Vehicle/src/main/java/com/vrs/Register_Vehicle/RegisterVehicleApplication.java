package com.vrs.Register_Vehicle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterVehicleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterVehicleApplication.class, args);
	}

}
