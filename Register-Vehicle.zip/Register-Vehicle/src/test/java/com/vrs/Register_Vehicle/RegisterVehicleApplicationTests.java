package com.vrs.Register_Vehicle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterVehicleApplicationTests {

	@Test
	void contextLoads() {
	}

}
